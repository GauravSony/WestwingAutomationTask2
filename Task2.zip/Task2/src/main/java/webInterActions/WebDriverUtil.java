package webInterActions;


import commonUtils.PropertyUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WebDriverUtil {

    final private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    final private static int waitTime = 60;
    final private static int JsLoadTime = 5;
    final private static Logger logger = Logger.getLogger("WebDriverUtil");

    static void setDriver(RemoteWebDriver driver) {
        WebDriverUtil.driver.set(driver);
    }


    public static String getSessionID() {
        String session = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
        System.out.println("Browser session id is : " + session);
        return session;
    }

    public static WebDriver getWebDriver() {
        return driver.get();
    }

    /**
     * This method will initiate the WebDriver
     */
    public static void initWebDriver(){
        logger.info("Initializing driver");
        WebDriverManager.chromedriver().setup();
        System.out.println("Using chrome driver : " + WebDriverManager.chromedriver().getDownloadedDriverPath());
        ChromeOptions options = new ChromeOptions();
        options.setPageLoadStrategy(PageLoadStrategy.NONE);
        //Disable notification will block popups such as "Wants to know your location"
        //Disable information bar will block messages such as "Chrome is being controlled by automated test software"
        options.addArguments("--disable-gpu", "--disable-notifications", "disable-infobars");
        options.addArguments("--disable-plugins");
        options.addArguments("--disable-extensions");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-web-security");
        options.addArguments("--no-proxy-server");
        Map<String, Object> prefs = new HashMap<String, Object>();
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.password_manager_enabled", false);
        options.setExperimentalOption("prefs", prefs);
        setDriver(new ChromeDriver(options));
    }

    /**
     * This method will verify if the element is present in DOM or not
     *
     * @param by
     * @return
     */
    public static boolean isElementPresent(By by) {
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), 0);
            wait.until(ExpectedConditions.presenceOfElementLocated(by));
            return true;
        } catch (Exception e) {
            logger.info("Error in finding presence of element  " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    /**
     * This method will verify if the element is present in DOM or not
     *
     * @param ele
     * @return
     */
    public static boolean isDisplayed(WebElement ele) {
        try {
            if (ele.isDisplayed()) {
                highLightElement(ele, "blue");
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Wait until element is visible in DOM
     *
     * @param locator
     */
    public static void waitUntilVisibilityOf(WebElement locator) {
        waitUntilVisibilityOf(locator, waitTime);
    }

    /**
     * Wait until element is visible in DOM
     *
     * @param locator, highlightElement
     */
    public static void waitUntilVisibilityOf(WebElement locator, boolean highlightElement) {
        waitUntilVisibilityOf(locator, waitTime, highlightElement);
    }

    /**
     * Wait until element is visible in DOM
     *
     * @param locator, Seconds
     */
    public static void waitUntilVisibilityOf(WebElement locator, int seconds) {
        try {
            logger.info("Waiting for " + locator);
            WebDriverWait wait = new WebDriverWait(getWebDriver(), seconds);
            wait.until(ExpectedConditions.visibilityOf(locator));
            highLightElement(locator);
            logger.info("Done");
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }

    /**
     * Wait until element is visible in DOM
     *
     * @param locator, Seconds, highlightElement
     */
    public static void waitUntilVisibilityOf(WebElement locator, int seconds, boolean highlightElement) {
        try {
            logger.info("Waiting for " + locator);
            WebDriverWait wait = new WebDriverWait(getWebDriver(), seconds);
            wait.until(ExpectedConditions.visibilityOf(locator));
            if (highlightElement) {
                highLightElement(locator);
            }
            logger.info("Done");
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }


    /**
     * Wait numberOfWindowsToBe
     */
    public static void waitUntilNumberOfWindowsToBe(int NoOFwindow) {
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), 15);
            wait.until(ExpectedConditions.numberOfWindowsToBe(NoOFwindow));
            logger.info("Waiting done for No of Wndows to be " + NoOFwindow);
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }


    /**
     * Wait until element is visible in DOM
     *
     * @param locator, Seconds
     */
    public static void waitUntilPresenceOfAll(By locator) {
        try {
            logger.info("Waiting for " + locator);
            WebDriverWait wait = new WebDriverWait(getWebDriver(), waitTime);
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
            logger.info("Done");
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }

    /**
     * Wait until element is visible in DOM
     *
     * @param locator
     */
    public static WebElement waitUntilVisibilityOf(By locator) {
        return waitUntilVisibilityOf(locator, waitTime);
    }


    /**
     * Wait until element is visible in DOM
     *
     * @param locator, Seconds
     */
    public static WebElement waitUntilVisibilityOf(By locator, int seconds) {
        WebElement webElement = null;
        try {
            logger.info("Waiting for " + locator);
            WebDriverWait wait = new WebDriverWait(getWebDriver(), (seconds / 2));
            wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            WebDriverWait waitV = new WebDriverWait(getWebDriver(), (seconds / 2));
            webElement = driver.get().findElement(locator);
            waitV.until(ExpectedConditions.visibilityOf(webElement));
            highLightElement(webElement);
            logger.info("Done");
        } catch (Exception e) {
            logger.info("Waiting failed element visibility failed " + e.getMessage());
        }
        return webElement;
    }

    /**
     * This method will wait for all element array to be visible
     *
     * @param locator
     */
    public static void waitUntilVisibilityOfAll(List<WebElement> locator) {
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), waitTime);
            wait.until(ExpectedConditions.visibilityOfAllElements(locator));
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }

    /**
     * Wait until element is disappear
     *
     * @param locator
     */
    public static void waitUntilInVisibilityOf(By locator) {
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), 60);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
        } catch (Exception e) {
            logger.info("waiting failed element invisibility failed" + e.getMessage());
        }
    }


    /**
     * Wait until element is clickable in DOM
     *
     * @param locator
     */
    public static void waitUntilClickable(WebElement locator) {
        try {
            logger.info("Waiting for element to be clickable" + locator);
            WebDriverWait wait = new WebDriverWait(getWebDriver(), waitTime);
            wait.until(ExpectedConditions.elementToBeClickable(locator));
            logger.info("Done");
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }


    /**
     * Wait until all javascript and JQueries are finished
     *
     * @return
     */
    public static boolean waitForJStoLoad() {
        return waitForJStoLoad(JsLoadTime);
    }

    /**
     * Wait until all javascripts and jqueries are finished
     *
     * @return
     */
    public static boolean waitForJStoLoad(int seconds) {
        logger.info("Waiting for page to load");
        try {
            final JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
            WebDriverWait wait = new WebDriverWait(getWebDriver(), seconds);
            // wait for jQuery to load
            ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
                @Override
                public Boolean apply(WebDriver driver) {
                    try {
                        return ((Long) jse.executeScript("return jQuery.active") == 0);
                    } catch (Exception e) {
                        return true;
                    }
                }
            };
            // wait for Javascript to load
            ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
                @Override
                public Boolean apply(WebDriver driver) {
                    return jse.executeScript("return document.readyState")
                            .toString().equals("complete");
                }
            };
            System.out.println("Page is loaded");
            return wait.until(jQueryLoad) && wait.until(jsLoad);
        } catch (Exception ex) {
            logger.info("JS did not loaded in " + seconds + " seconds");
        }
        return false;
    }

    /**
     * This method will clear cache of IE
     */
    public static void clearCache() {
        try {
            Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255");
            Thread.sleep(500);
        } catch (Exception ex) {
            logger.error("Error in clearCache" + ex);
        }
    }

    /**
     * This method will delete all cookies
     */
    public static void deleteCookies() {
        try {
            getWebDriver().manage().deleteAllCookies();
            Thread.sleep(1000);
        } catch (Exception ex) {
            logger.error("Error in deleteCookies" + ex);
        }
    }

    public static void loadUrl(String url) {
        try {
            System.out.println("Loading url : " + url);
            getWebDriver().get(url);
        } catch (Exception e) {
            getWebDriver().get(url);
        }
    }

    public static void executeScript(String script) {
        ((JavascriptExecutor) getWebDriver()).executeScript(script);
    }

    public static void quit() {
        //service.stop();
        getWebDriver().quit();
    }


    public static void highLightElement(WebElement ele) {
        highLightElement(ele, "red");
    }

    //use executeScript() method and pass the arguments
    //Here i pass values based on css style. Yellow background color with solid red color border.
    public static void highLightElement(WebElement ele, String colour) {
        try {
            final JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
            jse.executeScript("arguments[0].setAttribute('style', 'border: 2px solid " + colour + ";');", ele);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    /**
     * This method will verify if the element is present in DOM or not
     *
     * @param ele
     * @return
     */
    public static boolean isDisplayed(By ele) {
        try {
            if (getWebDriver().findElement(ele).isDisplayed()) {
                highLightElement(getWebDriver().findElement(ele), "blue");
                return true;
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }


    /**
     * Wait until element is disappear
     *
     * @param locator
     */
    public static void waitUntilInVisibilityOf(WebElement locator) {
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), 5);
            wait.until(ExpectedConditions.invisibilityOf(locator));
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }

    /**
     * Wait until element is disappear
     *
     * @param locator
     */
    public static void waitUntilInVisibilityOf(List<WebElement> locator) {
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), waitTime);
            wait.until(ExpectedConditions.invisibilityOfAllElements(locator));
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }


    /**
     * Wait until element is present in DOM
     *
     * @param locator, Seconds
     */
    public static void waitUntilPresenceOf(By locator, int seconds) {
        try {
            logger.info("Waiting for presence of  " + locator);
            WebDriverWait wait = new WebDriverWait(getWebDriver(), seconds);
            wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            logger.info("Done");
        } catch (Exception e) {
            logger.info("There was an error " + e.getMessage());
        }
    }

    /**
     * This method will clear cache of IE
     */
    public static void timeout(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception ex) {
            logger.error("Error in waiting" + ex);
        }
    }

    /**
     * Click radio button by value
     *
     * @param webElements
     * @param value
     */
    public static void clickRadioHavingValue(List<WebElement> webElements, String value) {
        for (WebElement webElement : webElements) {
            if (webElement.getAttribute("value").equalsIgnoreCase(value)) {
                waitAndClick(webElement);
            }
        }
    }

    /**
     * This method will select value from dropdown list
     *
     * @param dropDown
     * @param value
     * @param selectionType
     */
    public static void selectFrommDropDown(WebElement dropDown, String value, String selectionType) {
        waitUntilVisibilityOf(dropDown);
        ClickWithJS(dropDown);
        Select objDropDown = new Select(dropDown);
        moveToElement(dropDown);
        if (selectionType.equalsIgnoreCase("text")) {
            objDropDown.selectByVisibleText(value);
        } else if (selectionType.equalsIgnoreCase("index")) {
            objDropDown.selectByIndex(Integer.parseInt(value));
        } else if (selectionType.equalsIgnoreCase("value")) {
            objDropDown.selectByValue(value);
        } else {
            objDropDown.selectByIndex(1);
        }
    }


    public static void moveToElement(WebElement element) {
        try {
            Actions action = new Actions(getWebDriver());
            action.moveToElement(element).build().perform();
        } catch (Exception ex) {
            logger.info("Error in hover element : " + ex.getMessage());
        }
    }


    public static void hoverClearSendKeys(WebElement element, String text) {
        try {
            sendKeysMain(element, text);
        } catch (ElementClickInterceptedException | StaleElementReferenceException e) {
            sendKeysMain(element, text);
        }
    }

    private static void sendKeysMain(WebElement element, String text) {
        waitAndClick(element);
        moveToElement(element);
        clearInputEle(element);
        element.sendKeys(text);
    }

    /*
     * This method will clear input element
     * @param element input element
     */
    public static void clearInputEle(WebElement element) {
        try {
            Actions action = new Actions(getWebDriver());
            action.click(element).sendKeys(Keys.END).keyDown(Keys.SHIFT)
                    .sendKeys(Keys.HOME).keyUp(Keys.SHIFT).sendKeys(Keys.BACK_SPACE)
                    .perform();
        } catch (Exception ex) {
            logger.info("Error in clear input element : " + ex.getMessage());
            logger.info("executing element.clear() as back up");
            element.clear();
        }
    }

    public static void sendKeysJs(WebElement ele, String value) {
        try {
            final JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
            jse.executeScript("arguments[0].setAttribute('value', '" + value + "');", ele);
            System.out.println("send key using javascript executed");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    public static void waitAndClick(WebElement el) {
        try {
            waitUntilClickable(el);
            highLightElement(el);
            el.click();
        } catch (StaleElementReferenceException | ElementNotInteractableException e) {
            System.out.println(el.toString() + " is attempted to click second time");
            click(el);
        }
    }

    private static void click(WebElement element) {
        element.click();
    }


    public static void ClickWithJS(WebElement ele) {
        waitUntilClickable(ele);
        final JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
        jse.executeScript("arguments[0].click();", ele);
    }

    public static void switchToFirstTab() {
        ArrayList<String> tabs = new ArrayList<String>(getWebDriver().getWindowHandles());
        try {
            for (int i = 1; i < tabs.size(); i++) {
                try {
                    getWebDriver().switchTo().window(tabs.get(i)).close();
                } catch (NoSuchWindowException e) {
                }
            }
            getWebDriver().switchTo().window(tabs.get(0));
        } catch (Exception e) {
        }
    }

    /**
     * This method will double click on element
     *
     * @param el
     */
    public static void waitAndDoubleClick(WebElement el) {
        Actions actions = new Actions((WebDriver) driver);
        waitUntilClickable(el);
        highLightElement(el);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", el);
        actions.doubleClick(el).perform();
    }

    /**
     * This method capture screenshot for web page
     */
    public static byte[] captureScreenshot() {
        return ((TakesScreenshot) WebDriverUtil.getWebDriver()).getScreenshotAs(OutputType.BYTES);
    }

    /**
     * Find row from table
     *
     * @param tableEle table element
     * @param match    data to be matched to find Row
     */
    public static WebElement findRowFromTable(WebElement tableEle, String match) {
        WebDriverUtil.waitUntilVisibilityOf(tableEle);
        List<WebElement> rows = tableEle.findElements(By.tagName("tr"));
        if (null != rows) {
            for (WebElement rowEle : rows) {
                WebElement tdEle = rowEle.findElements(By.tagName("td")).stream()
                        .filter(element -> match.equals(element.getText()))
                        .findAny().orElse(null);
                if (null != tdEle) {
                    return rowEle;
                }
            }
        }
        return null;
    }


    /**
     * Switch the iframe from the parent to new one
     *
     * @param iframe
     */
    public static void switchToIframe(WebElement iframe) {
        waitForJStoLoad(waitTime);
        waitUntilVisibilityOf(iframe);
        getWebDriver().switchTo().frame(iframe);
        waitForJStoLoad(waitTime);
    }

    /**
     * Switch the iframe from the new one to parent
     */
    public static void switchToParentFrame() {
        WebDriverUtil.getWebDriver().switchTo().parentFrame();
    }

    /**
     * press ok when a alert is displayed
     *
     * @throws InterruptedException
     */
    public static void pressOkInAlert() {
        waitAlertToLoad(waitTime);
        WebDriverUtil.getWebDriver().switchTo().alert().accept();
    }

    /**
     * This method used to switch to pop up window.
     *
     * @return current window ie parent window name for switch on later if required
     */
    public static String switchToPopUpWindow() {
        String currentWindowHandler = getWebDriver().getWindowHandle();

        String popUpWindowHandler = getWebDriver().getWindowHandles().stream()
                .filter(windowHandler -> !windowHandler.equalsIgnoreCase(currentWindowHandler))
                .findFirst()
                .orElse(currentWindowHandler);

        switchToWindow(popUpWindowHandler);

        return currentWindowHandler;
    }

    /**
     * This method used to switch to any window by name
     *
     * @param windowHandlerName to be used to switch specific window
     */
    public static void switchToWindow(String windowHandlerName) {
        getWebDriver().switchTo().window(windowHandlerName);
    }

    /**
     * Wait until all alertBox is loaded
     * @param seconds maximum wait time in no of seconds
     */
    public static void waitAlertToLoad(int seconds) {
        logger.info("Waiting for alertBox to load");
        try {
            WebDriverWait wait = new WebDriverWait(getWebDriver(), seconds);
            wait.until(ExpectedConditions.alertIsPresent());
        } catch (Exception e) {
            logger.info("Error in finding presence of alert  " + e.getMessage());
            e.printStackTrace();
        }
    }
}