package webInterActions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class WebPageScroll {

    private static WebDriver driver;
    private static int scrollWait = 200;  // in milliseconds

    static {
        driver = WebDriverUtil.getWebDriver();
    }

    public static void scrollToElement(WebElement Ele) {
        try {
            WebDriverUtil.waitUntilVisibilityOf(Ele);
            JavascriptExecutor jse = ((JavascriptExecutor) driver);
            jse.executeScript("arguments[0].scrollIntoView(true);", Ele);
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scrollElementToMiddle(WebElement Ele) {
        try {
            WebDriverUtil.waitUntilVisibilityOf(Ele);
            String scrollElementIntoMiddle = "var viewPortHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);"
                    + "var elementTop = arguments[0].getBoundingClientRect().top;"
                    + "window.scrollBy(0, elementTop-(viewPortHeight/2));";
            ((JavascriptExecutor) driver).executeScript(scrollElementIntoMiddle, Ele);
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method will scroll down the page to defined height
     *
     * @param Ele
     * @param dimension
     */
    public static void halfscroll_Down(WebElement Ele, int dimension) {
        try {
            WebDriverUtil.waitUntilVisibilityOf(Ele);
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scroll(0," + dimension + ")", Ele);
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method will scroll down to 350 pixel
     *
     * @param Ele
     */
    public static void halfscroll_up(WebElement Ele) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scroll(0,-350)", Ele);
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scrollToBottom() {
        try {
            driver.switchTo().defaultContent();
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);");
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scrollDownSmooth() {
        try {
            for ( int i = 0; i < 2000; i++ ) {
                ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,10)", "");
            }
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scrollDownSmooth(WebElement Ele) {
        try {
            for ( int i = 0; i < 2000; i++ ) {
                WebDriverUtil.waitUntilVisibilityOf(Ele);
                JavascriptExecutor jse = ((JavascriptExecutor) driver);
                jse.executeScript("arguments[0].scrollIntoView(true);", Ele);
                jse.executeScript("window.scrollBy(0,-100)");
            }
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scrollToTop() {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollTo({ top: 0, behavior: 'smooth' });");
            WebDriverUtil.timeout(scrollWait);
        } catch (Exception e) {
            e.printStackTrace();
            WebDriverUtil.timeout(scrollWait);
        }
    }
}
