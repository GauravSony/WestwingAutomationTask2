package commonUtils;

import org.apache.commons.configuration.PropertiesConfiguration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtil {
    static Properties prop = new Properties();

    FileInputStream inputFile;
    private static final String PROPERTY_FILENAME = System.getProperty("user.dir") + "/configuration/config.properties";

    public PropertyUtil() {
        try {
            inputFile = new FileInputStream(new File(PROPERTY_FILENAME));
            prop.load(inputFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /***
     * This method will return value from property file
     * @param key String <p>Key for which the property value is to be found</p>
     * @return String <p>Property value</p>
     */
    public String getProperty(String key) {
        String returnProperty = prop.getProperty(key);
        try {
            inputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return returnProperty;
    }

    /**
     * This method will update value of specified key in property file
     * @param key String <p>Key for which the value is to be updated</p>
     * @param value String <p>Value of the property to be updated</p>
     */

    public void updateProperty(String key, String value) {
        try {
            PropertiesConfiguration conf = new PropertiesConfiguration(PROPERTY_FILENAME);
            conf.setProperty(key, value);
            conf.save();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
