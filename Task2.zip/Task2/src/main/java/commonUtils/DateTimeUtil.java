package commonUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class DateTimeUtil {

    private static DateFormat dateformat;
    private static Date date;

    public DateTimeUtil() {
        date = new Date();
    }

    /**
     * This method will return current date and time
     *
     * @return
     */
    public static String getCurrentDate(String dateFormat) {
        dateformat = new SimpleDateFormat(dateFormat);
        return dateformat.format(date).toString();
    }

    /**
     * To get current time in specific format
     * @return
     */
    public static String getCurrentTime()
    {
        TimeZone istTimeZone = TimeZone.getTimeZone("Asia/Kolkata");
        Calendar today = Calendar.getInstance(istTimeZone);
        SimpleDateFormat FORMATTER = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a z");
        System.out.println("Current Time : "+ FORMATTER.format(today.getTime()));  //07/15/2018 at 12:35AM IST
        return FORMATTER.format(today.getTime());
    }
}
