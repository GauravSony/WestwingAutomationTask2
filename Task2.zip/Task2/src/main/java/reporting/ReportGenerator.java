package reporting;


import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.Reportable;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


public class ReportGenerator {

    public void GenerateCucumberReport(String reportDirectory, String NameOfProject, String jsonFilePath, Map<String, String> reportMatadata){

        File reportOutputDirectory = new File(reportDirectory);
        File jsonFile = new File(jsonFilePath);
        List<String> jsonFiles = new ArrayList<>();

        for (File cucufile : jsonFile.listFiles()) {
            if (cucufile.isFile()) {
                if (FilenameUtils.getExtension(cucufile.getName().toString()).equalsIgnoreCase("json")) {
                    jsonFiles.add(cucufile.getAbsoluteFile().getAbsolutePath());
                    System.out.println(cucufile.getAbsoluteFile().getAbsolutePath());
                }
            }
        }


        String buildNumber = "1";
        String projectName = NameOfProject;
        boolean runWithJenkins = false;
        boolean parallelTesting = false;

        Configuration configuration = new Configuration(reportOutputDirectory, projectName);
// optional configuration
     /*   configuration.setParallelTesting(parallelTesting);
        configuration.setRunWithJenkins(runWithJenkins);
        configuration.setBuildNumber(buildNumber);*/
// addidtional metadata presented on main page

        for(Entry<String,String> entry : reportMatadata.entrySet())
        {
            configuration.addClassifications(entry.getKey(),entry.getValue());
        }
        ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
        Reportable result = reportBuilder.generateReports();
// and here validate 'result' to decide what to do
// if report has failed features, undefined steps etc
    }

}
