package reporting;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

public class HtmlReportGenerator {

    public void generateCucumberHTMLReport(String reportDirectory, String projectName, String jsonFilePath, Map<String, String> reportMetadata) {
        File reportOutputDirectory = new File(reportDirectory);
        File jsonFile = new File(jsonFilePath);
        List<String> jsonFiles = new ArrayList<>();

        for ( File cucumberReportFile : Objects.requireNonNull(jsonFile.listFiles()) ) {
            if (cucumberReportFile.isFile()) {
                if (FilenameUtils.getExtension(cucumberReportFile.getName()).equalsIgnoreCase("json")) {
                    jsonFiles.add(cucumberReportFile.getAbsolutePath());
                }
            }
        }

        Configuration configuration = new Configuration(reportOutputDirectory, projectName);

        for ( Entry<String, String> entry : reportMetadata.entrySet() ) {
            configuration.addClassifications(entry.getKey(), entry.getValue());
        }
        ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
        reportBuilder.generateReports();
    }
}
