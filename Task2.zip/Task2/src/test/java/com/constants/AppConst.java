package com.constants;

import java.time.Duration;

public class AppConst {


    final static public String browser="chrome";
    final static public Duration waitTime = Duration.ofSeconds(60);
    final static public int MAX_TRY_COUNT=3;
}
