package com.runners;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import webInterActions.WebDriverUtil;

import java.io.IOException;

@CucumberOptions(monochrome = true, plugin = {"json:target/cucumber/Cucumber.json"},
        tags = "@demo",
        glue = {"com.stepDefinitions"},
        features = "features"
)
public class TestRunner extends AbstractTestNGCucumberTests {

    @BeforeSuite
    public static void openBrowser() throws IOException {
        System.out.println("Before suit started");
        WebDriverUtil.initWebDriver();
        WebDriverUtil.timeout(1);
        WebDriverUtil.getWebDriver().manage().window().maximize();
        WebDriverUtil.timeout(1000);
        System.out.println("Before suits finished" + WebDriverUtil.getWebDriver().manage().window().getSize());
    }

    @AfterSuite
    public static void closeBrowser() {
        WebDriverUtil.quit();
        Report.main(null);
    }
}