package com.runners;


import commonUtils.DateTimeUtil;
import commonUtils.PropertyUtil;
import reporting.HtmlReportGenerator;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Report {

    final private static PropertyUtil PROPERTY = new PropertyUtil();
    final private static String PROJECT_NAME = "Automation Task 2";
    final private static String JSON_REPORT_LOC = System.getProperty("user.dir") + "/target/cucumber";
    final private static String HTML_REP_LOC_PREFIX = System.getProperty("user.dir") + "/reports/html/Report_";
    final private static String MAIN_HTML_FILE = "/cucumber-html-reports/overview-features.html";


    /**
     * Generate HTML report from cucumber json files
     */
    public static void main(String[] args) {

        HtmlReportGenerator reporter = new HtmlReportGenerator();
        String curReportLoc = getLocationForNewReport();
        reporter.generateCucumberHTMLReport(curReportLoc, PROJECT_NAME, JSON_REPORT_LOC, getReportMetaData());
        OpenReport(PROPERTY.getProperty("ShowReportInBrowser"), curReportLoc);

    }

    /**
     * Generates path for new report with current timestamp
     */
    private static String getLocationForNewReport() {
        String timeString = DateTimeUtil.getCurrentTime().replaceAll("[/, :]", "_");
        return HTML_REP_LOC_PREFIX + timeString;
    }

    /**
     * Attach metadata in report
     */
    private static Map<String, String> getReportMetaData() {
        Map<String, String> metaData = new HashMap<>();
        metaData.put("Application Name : ", "Westwing");
        return metaData;
    }

    /**
     * Open report in browser
     */
    private static void OpenReport(String openInBrowser, String reportLoc) {
        try {
            if (openInBrowser.equalsIgnoreCase("yes")) {
                File htmlFile = new File(reportLoc + MAIN_HTML_FILE);
                Desktop.getDesktop().browse(htmlFile.toURI());
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

}