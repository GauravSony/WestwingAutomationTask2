package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import webInterActions.WebDriverUtil;

import java.util.List;


public class FavoritePage {

    WebDriver driver;

    public FavoritePage() {
        driver = WebDriverUtil.getWebDriver();
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = ".qaBlockListProduct__delete")
    List<WebElement> allProductsFavDel;

    public void deleteFirstFavPrd() {
        WebDriverUtil.waitUntilVisibilityOfAll(allProductsFavDel);
        WebElement el= allProductsFavDel.get(0);
        WebDriverUtil.waitAndClick(el);
        WebDriverUtil.timeout(500);
        WebDriverUtil.waitUntilInVisibilityOf(el);
    }

}