package com.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import webInterActions.WebDriverUtil;


public class HomePage {

    WebDriver driver;
    public HomePage()
    {
        driver=WebDriverUtil.getWebDriver();
        PageFactory.initElements(driver,this);
    }

    @FindBy(id = "onetrust-accept-btn-handler")
    WebElement acceptCookiesBtn;

    @FindBy(xpath = ".//input[@data-testid=\"search-input\"]")
    WebElement searchInput;

    @FindBy(name = "email")
    WebElement email;

    @FindBy(name = "password")
    WebElement passwordIn;

    @FindBy(xpath = ".//*[@data-testid=\"login-button\"]")
    WebElement loginLink;

    @FindBy(xpath = ".//*[@data-testid=\"login_reg_submit_btn\"]")
    WebElement login_submit;

    @FindBy(xpath = ".//*[@data-testid=\"wishlist-counter\"]")
    WebElement wishListCount;

    @FindBy(css = ".icon-wishlist")
    WebElement wishListIcone;





    public void login(String username, String password)
    {
        WebDriverUtil.hoverClearSendKeys(email,username);
        WebDriverUtil.hoverClearSendKeys(passwordIn,password);
        WebDriverUtil.waitAndClick(login_submit);
        WebDriverUtil.timeout(200);
        WebDriverUtil.waitUntilInVisibilityOf(login_submit);
    }

    public void acceptCookies()
    {
        WebDriverUtil.waitAndClick(acceptCookiesBtn);
        WebDriverUtil.timeout(200);
        WebDriverUtil.waitUntilInVisibilityOf(acceptCookiesBtn);
    }

    public void switchToLoginOverLay()
    {
        WebDriverUtil.waitAndClick(loginLink);
        WebDriverUtil.timeout(500);
    }

    public void searchProduct(String product)
    {
      WebDriverUtil.hoverClearSendKeys(searchInput,product+""+ Keys.ENTER);
        WebDriverUtil.timeout(2000);
    }

    public boolean verifyLoginPopUp()
    {
        WebDriverUtil.waitUntilVisibilityOf(loginLink);
        return WebDriverUtil.isDisplayed(loginLink);
    }

    public int getWishListCount()
    {
        WebDriverUtil.waitUntilVisibilityOf(wishListCount);
        if(WebDriverUtil.isDisplayed(wishListCount))
            return Integer.parseInt(wishListCount.getText());
        else
            return 0;
    }

    public void goToWishListPage()
    {
        WebDriverUtil.waitAndClick(wishListIcone);
        WebDriverUtil.timeout(500);
    }

}