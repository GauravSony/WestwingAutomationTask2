package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import webInterActions.WebDriverUtil;

import java.util.List;


public class ProductListPage {

    WebDriver driver;

    public ProductListPage() {
        driver = WebDriverUtil.getWebDriver();
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = ".dimkmn")
    List<WebElement> allProducts;

    @FindBy(xpath = ".//*[@data-is-selected=\"false\"]")
    List<WebElement> allProductsFavIcn;

    @FindBy(xpath = ".//*[@data-is-selected=\"true\"]")
    List<WebElement> allProductsFavIcnFilled;


    public boolean verifyProductsAreVisible() {
        WebDriverUtil.waitUntilVisibilityOfAll(allProducts);
        for (int i=0;i<5;i++) {
            if (!WebDriverUtil.isDisplayed(allProducts.get(i)))
                return false;
        }
        return true;
    }

    public void clickFavOfFirstPrd()
    {
        WebDriverUtil.waitUntilVisibilityOfAll(allProducts);
        WebDriverUtil.moveToElement(allProducts.get(0));
        WebDriverUtil.waitAndClick(allProductsFavIcn.get(0));
        WebDriverUtil.timeout(2000);
    }

    public boolean verifyFirstProductIsMarkedFav()
    {
        WebDriverUtil.waitUntilVisibilityOfAll(allProductsFavIcnFilled);
        return WebDriverUtil.isDisplayed(allProductsFavIcnFilled.get(0));
    }






}
