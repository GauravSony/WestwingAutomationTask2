package com.stepDefinitions;

import com.pages.FavoritePage;
import com.pages.HomePage;
import com.pages.ProductListPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;


public class CommonSteps {


    HomePage homePage;
    ProductListPage plpPage;
    FavoritePage favPage;
    public CommonSteps() {
      homePage= new HomePage();
      plpPage= new ProductListPage();
      favPage=new FavoritePage();
    }

    @Given("I am on the WestwingNow home page")
    public void iAmOnTheWestwingNowHomePage() {
    }

    @When("I search for {string}")
    public void iSearchFor(String arg0) {
        homePage.searchProduct(arg0);
    }

    @Then("I should see product listing page with a list of products")
    public void iShouldSeeProductListingPageWithAListOfProducts() {
        Assert.assertTrue(plpPage.verifyProductsAreVisible(),"All products are not displaying");
    }

    @When("I click on wishlist icon of the first found product")
    public void iClickOnWishlistIconOfTheFirstFoundProduct() {
        plpPage.clickFavOfFirstPrd();
    }

    @Then("I should see the login|registration overlay")
    public void iShouldSeeTheLoginRegistrationOverlay() {
        Assert.assertTrue(homePage.verifyLoginPopUp(),"Login popup is not present on screen");
    }

    @When("I switch to login form of the overlay")
    public void iSwitchToLoginFormOfTheOverlay() {
        homePage.switchToLoginOverLay();
    }

    @And("I log in with username {string} and password {string}")
    public void iLogInWithUsernameAndPassword(String arg0, String arg1) {
        homePage.login(arg0,arg1);
    }

    @Then("the product should be added to the wishlist")
    public void theProductShouldBeAddedToTheWishlist() {
        Assert.assertTrue(plpPage.verifyFirstProductIsMarkedFav(),"First product is not marked as favorite");
    }

    @Then("wishlist icon on the product is filled in")
    public void wishlistIconOnTheProductIsFilledIn() {
        boolean res= plpPage.verifyFirstProductIsMarkedFav();
        Assert.assertTrue(res,"First is not marked as fav");

    }

    @And("wishlist counter in the website header shows {int}")
    public void wishlistCounterInTheWebsiteHeaderShows(int arg0) {
        int wcnt= homePage.getWishListCount();
        Assert.assertEquals(wcnt,arg0,"Wish list count is not same as expected count");

    }

    @And("I go to the wishlist page")
    public void iGoToTheWishlistPage() {
        homePage.goToWishListPage();
    }

    @And("I delete the product from my wishlist")
    public void iDeleteTheProductFromMyWishlist() {
        favPage.deleteFirstFavPrd();
    }
}

