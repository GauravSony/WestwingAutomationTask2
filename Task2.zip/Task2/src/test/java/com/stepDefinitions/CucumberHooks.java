package com.stepDefinitions;

import com.pages.HomePage;
import commonUtils.PropertyUtil;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import webInterActions.WebDriverUtil;


public class CucumberHooks {

    protected static Logger logger;
    protected static String appURL;
    protected static io.cucumber.java.Scenario scenario = null;
    protected static PropertyUtil property = new PropertyUtil();

    static {
        appURL =   property.getProperty("env.baseurl");
        logger = Logger.getLogger("CucumberHooks");
    }


    public static void printScenarioStatus(Scenario scenario)
    {
        logger.info("************* The test " + scenario.getName() + " is " + scenario.getStatus() + " *****************");
    }

    protected static void attachScreenshot(Scenario scenario)
    {
        final byte[] screenshot = ((TakesScreenshot) WebDriverUtil
                .getWebDriver()).getScreenshotAs(OutputType.BYTES);
        scenario.attach(screenshot, "image/png",""); // stick it in the report
    }



    /**
     * This method is called before each scenario
     */
    @Before(order = 0)
    public static void loadBaseUrl(Scenario scenario) {
        try {
            System.out.println("Failure in before start");
            WebDriverUtil.switchToFirstTab();
            WebDriverUtil.loadUrl(appURL);
            CucumberHooks.scenario = scenario;
            (new HomePage()).acceptCookies();
            System.out.println("Failure in before end");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failure in before hooks");
        }
    }

    /**
     * This method will be called after each scenario, it will take screen shot
     * if test case is failed
     *
     * @param scenario
     */
    @After(order = 0)
    public static void takeScreenShot(Scenario scenario) {
        try {
            if (scenario.isFailed())
                attachScreenshot(scenario);
            printScenarioStatus(scenario);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failure in after hooks");
        }
    }
}